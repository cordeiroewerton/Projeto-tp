#include <iostream>
#include <fstream>
using namespace std;
#include "..\Resource Files\Conta.cpp"
#include "..\Header Files\ContaPoupanca.h"
int main(){
    Conta *b = new ContaPoupanca("Valmir Ferreira da Silva",1289373876,21,300000,{"13737838374","Alagoas","Arapiraca","rt"});

}
